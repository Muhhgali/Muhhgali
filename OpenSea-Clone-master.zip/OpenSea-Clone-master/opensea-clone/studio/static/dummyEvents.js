export const dummyEvents = [
    {
      price: 17,
      from: '0xQazi',
      to: '0xDavid',
      date: '4 months ago',
    },
    {
      price: 17,
      from: '0xQazi',
      to: '0xDavid',
      date: '4 months ago',
    },
    {
      price: 17,
      from: '0xQazi',
      to: '0xDavid',
      date: '4 months ago',
    },
    {
      price: 17,
      from: '0xQazi',
      to: '0xDavid',
      date: '4 months ago',
    },
  ]